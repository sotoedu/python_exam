print('Hello, world!')
print(                  )
