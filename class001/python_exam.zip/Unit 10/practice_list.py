a = list(range(5, -10, -2))

print(a)
