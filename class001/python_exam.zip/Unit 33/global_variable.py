x = 10          # 전역 변수
def foo():
    print(x)    # 전역 변수 출력

foo()
print(x)        # 전역 변수 출력
