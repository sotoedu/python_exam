#
#
#
#

print(s)
