single_quote = '''"안녕하세요."
'파이썬'입니다.'''

double_quote1 = """"Hello"
'Python'"""

double_quote2 = """Hello, 'Python'"""    # 한 줄로 작성

print(single_quote)
print(double_quote1)
print(double_quote2)
