from math import ceil, floor

x = 1.5

print(ceil(x), floor(x))
