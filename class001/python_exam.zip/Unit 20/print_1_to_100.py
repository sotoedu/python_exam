for i in range(1, 101):    # 1부터 100까지 100번 반복
    print(i)
