age = int(input())
balance = 9000    # 교통카드 잔액

#
#
#
#
#
#

print(balance)
