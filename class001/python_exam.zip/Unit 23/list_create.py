a = []    # 빈 리스트 생성

for i in range(10):
    a.append(0)    # append로 요소 추가

print(a)
