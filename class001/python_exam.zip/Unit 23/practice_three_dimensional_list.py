a = [[[0 for col in range(3)] for row in range(4)] for depth in range(2)]

print(a)
