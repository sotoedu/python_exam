a, b, c = map(int, input().split())

print(a + b + c)
