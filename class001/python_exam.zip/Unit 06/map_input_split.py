a, b = map(int, input('숫자 두 개를 입력하세요: ').split())

print(a + b)
