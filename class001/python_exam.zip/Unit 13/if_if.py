x = 15

if x >= 10:
    print('10 이상입니다.')

    if x == 15:
        print('15입니다.')

    if x == 20:
        print('20입니다.')
