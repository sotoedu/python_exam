x = 10

if x == 10:
    print('x에 들어있는 숫자는')
        print('10입니다.')     # unexpected indent 에러 발생
