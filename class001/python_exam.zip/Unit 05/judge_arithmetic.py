print(102            )
