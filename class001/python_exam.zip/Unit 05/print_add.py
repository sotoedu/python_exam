print(1 + 1)
