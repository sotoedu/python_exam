i = 2
j = 5

while i <= 32 or j >= 1:
    print(i, j)
    i *= 2
    j -= 1
