while True:    # while에 True를 지정하면 무한 루프
    print('Hello, world!')
