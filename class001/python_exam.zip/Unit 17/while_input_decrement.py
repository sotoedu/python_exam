count = int(input('반복할 횟수를 입력하세요: '))

while count > 0:     # count가 0보다 클 때 반복
    print('Hello, world!', count)
    count -= 1       # count를 1씩 감소시킴
