count = int(input('반복할 횟수를 입력하세요: '))

i = 0
while i < count:     # i가 count보다 작을 때 반복
    print('Hello, world!', i)
    i += 1
