x = input().split()

#

#
