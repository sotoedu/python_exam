print(1)
print(2)
print(3)
