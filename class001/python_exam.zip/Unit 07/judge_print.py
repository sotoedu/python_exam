year, month, day, hour, minute, second = input().split()

#
print(hour, minute, second, sep=':')
