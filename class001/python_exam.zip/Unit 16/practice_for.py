x = [49, -17, 25, 102, 8, 62, 21]

for i in x:
    print(i * 10, end=' ')
