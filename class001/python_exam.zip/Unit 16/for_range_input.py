count = int(input('반복할 횟수를 입력하세요: '))

for i in range(count):
    print('Hello, world!', i)
