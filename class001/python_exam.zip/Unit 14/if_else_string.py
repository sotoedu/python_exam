if 'Hello':    # 문자열
    print('참')    # 문자열은 참
else:
    print('거짓')

if '':    # 빈 문자열
    print('참')
else:
    print('거짓')    # 빈 문자열은 거짓
