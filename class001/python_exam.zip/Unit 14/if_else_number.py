if 0:
    print('참')
else:
    print('거짓')    # 0은 거짓

if 1:
    print('참')    # 1은 참
else:
    print('거짓')

if 0x1F:    # 16진수
    print('참')    # 0x1F는 참
else:
    print('거짓')

if 0b1000:    # 2진수
    print('참')    # 0b1000은 참
else:
    print('거짓')

if 13.5:    # 실수
    print('참')    # 13.5는 참
else:
    print('거짓')
