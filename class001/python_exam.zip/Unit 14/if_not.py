if not 0:
    print('참')    # not 0은 참

if not None:
    print('참')    # None은 참

if not '':
    print('참')    # not 빈 문자열은 참
