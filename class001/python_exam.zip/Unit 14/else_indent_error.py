x = 5

if x == 10:
    print('10입니다.')
else:
print('x에 들어있는 숫자는')    # unexpected indent 에러 발생
    print('10이 아닙니다.')
