if True:
    print('참')    # True는 참
else:
    print('거짓')

if False:
    print('참')
else:
    print('거짓')    # False는 거짓

if None:
    print('참')
else:
    print('거짓')    # None은 거짓
