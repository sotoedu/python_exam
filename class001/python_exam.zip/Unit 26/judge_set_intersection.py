#

#
#

divisor = a & b

result = 0
if type(divisor) == set:
    result = sum(divisor)

print(result)
