files = input().split()

print(                                                                                        )
