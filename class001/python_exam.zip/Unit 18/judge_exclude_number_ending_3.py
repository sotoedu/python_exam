start, stop = map(int, input().split())

i = start

while True:
    #
    #
    #
    #
    #
    print(i, end=' ')
    i += 1
