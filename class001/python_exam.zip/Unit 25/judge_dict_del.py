keys = input().split()
values = map(int, input().split())

x = dict(zip(keys, values))

#
#

print(x)
