import hello    # hello 모듈을 가져옴

print('main.py __name__:', __name__)    # __name__ 변수 출력
