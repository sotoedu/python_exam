def product(a, b):
    pass

def dot(a, b):
    pass