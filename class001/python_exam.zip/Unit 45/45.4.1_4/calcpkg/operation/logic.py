def nand(a, b):
    pass

def nor(a, b):
    pass