import calcpkg

print(calcpkg.triangle_area(10, 20))
print(calcpkg.rectangle_area(30, 40))
