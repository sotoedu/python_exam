from database import *

connect(':memory:')
