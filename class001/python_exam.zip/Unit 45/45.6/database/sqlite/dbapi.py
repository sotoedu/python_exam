def connect(database):
    print(database)
