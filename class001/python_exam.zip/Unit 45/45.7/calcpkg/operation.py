import math

def squareroot(n):
    return math.sqrt(n)
