import math

def circle_area(radius):
    return radius * radius * math.pi
