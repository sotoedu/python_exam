base = 2          # 변수

def square(n):    # 함수
    return base ** n
