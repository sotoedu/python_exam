#
#
#
#
#

n = int(input())
print(fib(n))
