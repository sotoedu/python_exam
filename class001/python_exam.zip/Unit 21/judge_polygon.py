import turtle as t

n, line = map(int, input().split())
t.shape('turtle')
t.speed('fastest')
#
#
#
#
#
