import turtle as t

t.shape('turtle')
for i in range(4):    # 사각형이므로 4번 반복
    t.forward(100)
    t.right(90)
